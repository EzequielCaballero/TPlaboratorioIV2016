angular.module('ABMangularAPI.directivasLoading', [])

app.directive('loadingDirective', function() {

return {
	scope : {ver : '=cargando'}, 
	replace : true, 
	restrict : "MEAC", 
	templateUrl : "templates/templateGrillaUsuarios.html"};

})