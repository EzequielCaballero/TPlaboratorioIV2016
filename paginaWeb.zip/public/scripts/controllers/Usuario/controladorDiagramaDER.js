angular.module('ABMangularAPI.controladorDiagramaDER', [])  
  app.controller('controlDiagramaRelacional', function($scope, $http, $state, $auth) {

});