angular.module('ABMangularAPI.controladorDirectivasUsuario', []) 
  app.controller('controlDirectivaGrillaUser', function($scope, i18nService, uiGridConstants, factoryConServicio_User) {
    
    $scope.tituloGrilla = "FICHA USUARIOS";
    $scope.listadoUsuarios = [];
    //$scope.verUsuariosDirectiva = false;
    // $scope.cargando = true;

   factoryConServicio_User.traerTodos().then(function(respuesta){
      $scope.listadoUsuarios = respuesta.data;
      //$scope.verUsuariosDirectiva = false;
      // $scope.cargando = false;
      console.info("controllerDirectiva: ", $scope.listadoUsuarios);
    });
});
